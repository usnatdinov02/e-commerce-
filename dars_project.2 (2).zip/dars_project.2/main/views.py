from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.core.paginator import Paginator
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
import json
from .models import Category, Product, Cart, CartItem, Order, OrderItem
from .forms import UserRegistrationForm

def get_or_create_cart(request):
    """Savatchani olish yoki yaratish"""
    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
    else:
        session_key = request.session.session_key
        if not session_key:
            request.session.create()
            session_key = request.session.session_key
        cart, created = Cart.objects.get_or_create(session_key=session_key)
    return cart

def home(request):
    """Bosh sahifa"""
    featured_products = Product.objects.filter(is_featured=True, is_active=True)[:6]
    categories = Category.objects.all()[:6]
    
    context = {
        'featured_products': featured_products,
        'categories': categories,
    }
    return render(request, 'index.html', context)

def product_list(request):
    """Mahsulotlar ro'yxati"""
    products = Product.objects.filter(is_active=True)
    categories = Category.objects.all()
    
    # Qidiruv
    search_query = request.GET.get('search')
    if search_query:
        products = products.filter(
            Q(name__icontains=search_query) | 
            Q(description__icontains=search_query)
        )
    
    # Kategoriya bo'yicha filtr
    category_id = request.GET.get('category')
    if category_id:
        products = products.filter(category_id=category_id)
    
    # Pagination
    paginator = Paginator(products, 12)
    page_number = request.GET.get('page')
    products = paginator.get_page(page_number)
    
    context = {
        'products': products,
        'categories': categories,
        'search_query': search_query,
        'selected_category': category_id,
    }
    return render(request, 'products.html', context)

def product_detail(request, product_id):
    """Mahsulot tafsilotlari"""
    product = get_object_or_404(Product, id=product_id, is_active=True)
    related_products = Product.objects.filter(
        category=product.category, 
        is_active=True
    ).exclude(id=product_id)[:4]
    
    context = {
        'product': product,
        'related_products': related_products,
    }
    return render(request, 'product_detail.html', context)

def cart_view(request):
    """Savatcha sahifasi"""
    cart = get_or_create_cart(request)
    cart_items = cart.items.all()
    
    total_price = sum(item.total_price for item in cart_items)
    
    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }
    return render(request, 'cart.html', context)

@csrf_exempt
def add_to_cart(request):
    """Savatchaga qo'shish"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            product_id = data.get('product_id')
            quantity = int(data.get('quantity', 1))
            
            product = get_object_or_404(Product, id=product_id, is_active=True)
            cart = get_or_create_cart(request)
            
            cart_item, created = CartItem.objects.get_or_create(
                cart=cart,
                product=product,
                defaults={'quantity': quantity}
            )
            
            if not created:
                cart_item.quantity += quantity
                cart_item.save()
            
            return JsonResponse({
                'success': True,
                'message': f'{product.name} savatchaga qo\'shildi!',
                'cart_count': cart.items.count()
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': 'Xatolik yuz berdi!'
            })
    
    return JsonResponse({'success': False, 'message': 'Noto\'g\'ri so\'rov!'})

@csrf_exempt
def update_cart_item(request):
    """Savatcha elementini yangilash"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            item_id = data.get('item_id')
            quantity = int(data.get('quantity', 1))
            
            cart_item = get_object_or_404(CartItem, id=item_id)
            
            if quantity <= 0:
                cart_item.delete()
            else:
                cart_item.quantity = quantity
                cart_item.save()
            
            cart = cart_item.cart
            total_price = sum(item.total_price for item in cart.items.all())
            
            return JsonResponse({
                'success': True,
                'total_price': float(total_price),
                'cart_count': cart.items.count()
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': 'Xatolik yuz berdi!'
            })
    
    return JsonResponse({'success': False, 'message': 'Noto\'g\'ri so\'rov!'})

@csrf_exempt
def remove_from_cart(request):
    """Savatchadan o'chirish"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            item_id = data.get('item_id')
            
            cart_item = get_object_or_404(CartItem, id=item_id)
            cart_item.delete()
            
            cart = cart_item.cart
            total_price = sum(item.total_price for item in cart.items.all())
            
            return JsonResponse({
                'success': True,
                'total_price': float(total_price),
                'cart_count': cart.items.count()
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': 'Xatolik yuz berdi!'
            })
    
    return JsonResponse({'success': False, 'message': 'Noto\'g\'ri so\'rov!'})

def checkout(request):
    """Buyurtma berish sahifasi"""
    cart = get_or_create_cart(request)
    cart_items = cart.items.all()
    
    if not cart_items:
        messages.warning(request, 'Savatchangiz bo\'sh!')
        return redirect('cart')
    
    total_price = sum(item.total_price for item in cart_items)
    
    if request.method == 'POST':
        try:
            # Buyurtma yaratish
            order = Order.objects.create(
                user=request.user if request.user.is_authenticated else None,
                session_key=request.session.session_key if not request.user.is_authenticated else None,
                first_name=request.POST.get('first_name'),
                last_name=request.POST.get('last_name'),
                email=request.POST.get('email'),
                phone=request.POST.get('phone'),
                address=request.POST.get('address'),
                total_amount=total_price
            )
            
            # Buyurtma elementlarini yaratish
            for cart_item in cart_items:
                OrderItem.objects.create(
                    order=order,
                    product=cart_item.product,
                    quantity=cart_item.quantity,
                    price=cart_item.product.price
                )
            
            # Savatchani tozalash
            cart_items.delete()
            
            messages.success(request, f'Buyurtma muvaffaqiyatli berildi! Buyurtma raqami: #{order.id}')
            return redirect('order_success', order_id=order.id)
            
        except Exception as e:
            messages.error(request, 'Buyurtma berishda xatolik yuz berdi!')
    
    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }
    return render(request, 'checkout.html', context)

def order_success(request, order_id):
    """Buyurtma muvaffaqiyatli sahifasi"""
    order = get_object_or_404(Order, id=order_id)
    context = {'order': order}
    return render(request, 'order_success.html', context)

def category_products(request, category_id):
    """Kategoriya bo'yicha mahsulotlar"""
    category = get_object_or_404(Category, id=category_id)
    products = Product.objects.filter(category=category, is_active=True)
    
    # Pagination
    paginator = Paginator(products, 12)
    page_number = request.GET.get('page')
    products = paginator.get_page(page_number)
    
    context = {
        'category': category,
        'products': products,
    }
    return render(request, 'category_products.html', context)

def register(request):
    """Foydalanuvchi ro'yxatdan o'tish"""
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Xush kelibsiz, {user.first_name}! Ro\'yxatdan muvaffaqiyatli o\'tdingiz.')
            return redirect('home')
    else:
        form = UserRegistrationForm()
    
    context = {
        'form': form,
    }
    return render(request, 'register.html', context)

def user_logout(request):
    """Foydalanuvchi chiqish"""
    if request.user.is_authenticated:
        logout(request)
        messages.success(request, 'Siz muvaffaqiyatli tizimdan chiqdingiz.')
    return redirect('home')

def cart_count(request):
    """Savatcha elementlari sonini olish"""
    cart = get_or_create_cart(request)
    count = cart.items.count()
    return JsonResponse({'count': count})

@login_required
def user_profile(request):
    """Foydalanuvchi profili"""
    user = request.user
    orders = Order.objects.filter(user=user).order_by('-created_at')[:10]
    
    context = {
        'user': user,
        'orders': orders,
    }
    return render(request, 'user_profile.html', context)

@login_required
def order_history(request):
    """Buyurtmalar tarixi"""
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    
    # Pagination
    paginator = Paginator(orders, 10)
    page_number = request.GET.get('page')
    orders = paginator.get_page(page_number)
    
    context = {
        'orders': orders,
    }
    return render(request, 'order_history.html', context)

@login_required
def order_detail(request, order_id):
    """Buyurtma tafsilotlari"""
    order = get_object_or_404(Order, id=order_id, user=request.user)
    context = {
        'order': order,
    }
    return render(request, 'order_detail.html', context)